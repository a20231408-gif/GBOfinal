package com.tuempresa.inventariovial.scap.domain

import com.tuempresa.inventariovial.scap.catalog.ScapCatalog
import com.tuempresa.inventariovial.scap.data.ScapInspectionSnapshot

data class ScapPendingField(val section:String,val field:String,val ownerId:String="inspection",val key:String="")
data class ScapCompleteness(val complete:List<ScapPendingField>,val pending:List<ScapPendingField>)

/** Stable navigation destinations refer to capture section and row, never a dropdown index. */
object ScapCompletion {
    fun assess(snapshot:ScapInspectionSnapshot,catalog:ScapCatalog):ScapCompleteness {
        val complete=mutableListOf<ScapPendingField>();val pending=mutableListOf<ScapPendingField>()
        val owners=listOf("inspection","ACCESS_LEFT","ACCESS_RIGHT")+snapshot.spans.map{it.id}+snapshot.substructures.map{it.id}+snapshot.supports.map{it.id}+snapshot.joints.map{it.id}+snapshot.profile.map{it.id}
        owners.forEach {owner->
            val kind=ScapValidation.ownerType(snapshot,owner)
            val values=snapshot.values(owner)
            catalog.fields.filter{it.owner==kind && it.visible(values) && ScapFieldPolicy.enabled(it,values)}.distinctBy{it.section+it.key}.forEach {field->
                val item=ScapPendingField(field.section,field.label,owner,field.key)
                if(values[field.key].isNullOrBlank() || ScapValidation.fieldError(field,values[field.key].orEmpty(),values,catalog)!=null) pending+=item else complete+=item
            }
        }
        val review=ScapValidation.review(snapshot,catalog)
        (review.errors+review.pending).forEach {message->
            if(pending.any{message.contains(it.field)}) return@forEach
            val section=when {
                " · " in message && message.substringBefore(" · ") in catalog.fields.map{it.section}+listOf("G1")->message.substringBefore(" · ")
                message.startsWith("Tramo") || message.contains("tramo",true)->"C2"
                message.contains("elemento presente")->"F1"
                message.contains("metrado") || message.contains("evaluación") || message.contains("factor") || message.contains("porcentaje")->"G1"
                message.contains("fotográfic",true)->"FOTO"
                message.contains("Croquis")->"E"
                message.contains("Defecto")->"F2"
                else->"A"
            }
            pending+=ScapPendingField(section,message)
        }
        return ScapCompleteness(complete.distinct(),pending.distinct())
    }
}
