package com.tuempresa.inventariovial.sic

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.tuempresa.inventariovial.ChoiceSelector
import com.tuempresa.inventariovial.FinalLocationCapture
import com.tuempresa.inventariovial.core.*
import com.tuempresa.inventariovial.data.database.InventoryDatabase
import com.tuempresa.inventariovial.field.CulvertUnifiedScreen
import com.tuempresa.inventariovial.camera.PhotoCaptureMetadata
import com.tuempresa.inventariovial.export.*
import com.tuempresa.inventariovial.location.GeoLocation
import com.tuempresa.inventariovial.viewmodel.InventoryViewModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.util.UUID

@Composable
fun SicCodeDropdown(field:SicField,value:String,onChange:(String)->Unit,enabled:Boolean=true) {
    Column(verticalArrangement=Arrangement.spacedBy(6.dp)) {
        Text(field.label,style=MaterialTheme.typography.titleSmall)
        val labels=field.options.map {if(it.code==ACCIDENT_TYPE_SOURCE_CONFLICT) it.name else it.label}
        val selected=field.options.indexOfFirst {it.code==value}
        ChoiceSelector(labels,labels.getOrNull(selected).orEmpty(),enabled) {label->
            onChange(field.options[labels.indexOf(label)].code)
        }
    }
}

@Composable
fun InventoryElementWorkspace(vm:InventoryViewModel,format:SicFieldFormat,recordId:String?=null,onBack:()->Unit) {
    when(format) {
        SicFieldFormat.SIC08,SicFieldFormat.SIC09 -> FajaWorkspace(vm,recordId,onBack)
        SicFieldFormat.SIC18A -> if(recordId!=null) CulvertUnifiedScreen(vm,recordId,onBack=onBack) else Text("Selecciona una alcantarilla desde el historial")
        else -> SicFieldWorkspace(vm,format,recordId,onBack)
    }
}

@Composable
fun FajaWorkspace(vm:InventoryViewModel,recordId:String?=null,onBack:()->Unit) {
    val context=LocalContext.current
    val db=remember(context) {InventoryDatabase.getInstance(context)}
    val records by db.inventoryDao().observeAllRecords().collectAsState(initial=emptyList())
    val extensions by db.inventoryDao().observeSicExtensions().collectAsState(initial=emptyList())
    var selected by rememberSaveable(recordId) {mutableStateOf(recordId)}
    var creating by rememberSaveable {mutableStateOf(false)}
    var ready by remember(recordId) {mutableStateOf(recordId==null)}
    var standaloneWidths by rememberSaveable(recordId) {mutableStateOf(false)}
    LaunchedEffect(recordId) {
        if(recordId!=null) {
            val record=db.inventoryDao().recordById(recordId)
            val source=db.inventoryDao().sicExtension(recordId)?.sourceRecordId
            val parent=source?.let {db.inventoryDao().recordById(it)}
            val grouped=record!=null && parent!=null && InventoryElements.parentId(record,listOfNotNull(db.inventoryDao().sicExtension(recordId)),listOf(record,parent))==parent.id
            selected=if(grouped) parent!!.id else recordId
            standaloneWidths=record?.sicCode=="SIC-09" && !grouped
            ready=true
        }
    }
    if(!ready) {Text("Cargando faja…");return}
    if(creating || selected!=null) {
        val legacy=standaloneWidths || records.find {it.id==selected}?.sicCode=="SIC-09"
        SicFieldWorkspace(vm,if(legacy) SicFieldFormat.SIC09 else SicFieldFormat.SIC08,selected) {selected=null;creating=false;if(recordId!=null)onBack()}
        return
    }
    BackHandler(onBack=onBack)
    val fajas=InventoryElements.group(records.filter {it.sicCode in setOf("SIC-08","SIC-09") && it.status in setOf("ACTIVE","DRAFT")},extensions)
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=24.dp),contentPadding=PaddingValues(vertical=24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        item {OutlinedButton(onClick=onBack) {Text("Volver")};Text("Fajas",style=MaterialTheme.typography.headlineMedium);Text("SIC-08 · SIC-09",style=MaterialTheme.typography.bodySmall)}
        item {Button(onClick={creating=true}) {Text("+ Nueva faja")}}
        if(fajas.isEmpty()) item {Text("Todavía no hay fajas guardadas")}
        items(fajas,key={it.record.id}) {element->
            val ext=extensions.find {it.recordId==element.record.id}
            val values=ext?.values().orEmpty()
            val type=SicFieldFormat.fajaTypes.find {it.code==values["typeCode"]}?.name.orEmpty()
            val direction=SicFieldFormat.directions.find {it.code==values["directionCode"]}?.name.orEmpty()
            Card(Modifier.fillMaxWidth()) {Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("Faja ${values["faja"].orEmpty()} · $type · $direction",style=MaterialTheme.typography.titleLarge)
                Text("${element.record.routeCode} · ${element.record.roadbedCode}")
                Text("PR ${element.record.startPrCode}+${element.record.startDistanceM} → ${element.record.endPrCode.orEmpty()}+${element.record.endDistanceM ?: ""}")
                if(element.record.sicCode=="SIC-09") Text("Anchos históricos sin vínculo · datos conservados")
                else Text("Características · ${if(ext?.status=="COMPLETE") "✓" else "Pendiente"} · Anchos · ${if(element.children.any {child->extensions.any {it.recordId==child.id && it.status=="COMPLETE"}}) "✓" else "Pendiente"}")
                OutlinedButton(onClick={selected=element.record.id}) {Text("Abrir")}
            }}
        }
    }
}

@Composable
fun SicFieldWorkspace(vm:InventoryViewModel,format:SicFieldFormat,recordId:String?=null,onBack:()->Unit) {
    if(format==SicFieldFormat.SIC18A) {InventoryElementWorkspace(vm,format,recordId,onBack);return}
    val context=LocalContext.current
    val db=remember(context) {InventoryDatabase.getInstance(context)}
    val repo=remember(db) {SicFieldRepository(db)}
    val scope=rememberCoroutineScope()
    val extensions by db.inventoryDao().observeSicExtensions().collectAsState(initial=emptyList())
    val session by vm.field.session.collectAsState()
    val faja=format==SicFieldFormat.SIC08
    val id=rememberSaveable(format,recordId) {recordId ?: UUID.randomUUID().toString()}
    var source by rememberSaveable(format,recordId) {mutableStateOf<String?>(null)}
    var raw by rememberSaveable(format,recordId) {mutableStateOf("{}")}
    var loaded by rememberSaveable(format,recordId) {mutableStateOf(false)}
    var complete by rememberSaveable(format,recordId) {mutableStateOf(false)}
    var dirty by rememberSaveable(format,recordId) {mutableStateOf(false)}
    var widthId by rememberSaveable(format,recordId) {mutableStateOf(UUID.randomUUID().toString())}
    var widthRaw by rememberSaveable(format,recordId) {mutableStateOf("{}")}
    var widthComplete by rememberSaveable(format,recordId) {mutableStateOf(false)}
    var widthExpanded by rememberSaveable(format,recordId) {mutableStateOf(recordId==null)}
    var review by rememberSaveable {mutableStateOf(false)}
    var exit by remember {mutableStateOf(false)}
    var busy by remember {mutableStateOf(false)}
    var notice by remember {mutableStateOf<String?>(null)}
    var files by remember {mutableStateOf<List<GeneratedFile>>(emptyList())}
    var paths by rememberSaveable {mutableStateOf<List<String>>(emptyList())}
    var captures by remember {mutableStateOf<Map<String,PhotoCaptureMetadata>>(emptyMap())}
    var fix by remember {mutableStateOf<GeoLocation?>(null)}
    var endFix by remember {mutableStateOf<GeoLocation?>(null)}
    fun values(json:String)=JSONObject(json).let {j->j.keys().asSequence().associateWith {j.getString(it)}}
    val state=SicFieldState(format,values(raw),source)
    val widths=values(widthRaw)
    val widthState=SicFieldState(SicFieldFormat.SIC09,state.values.filterKeys {it in SicFieldRepository.sharedKeys || it=="faja"}+widths,id)
    val widthStarted=widths.values.any {it.isNotBlank()}
    val completion=CompletionResult(state.completion().issues+if(faja && widthStarted) widthState.completion().issues else emptyList())
    val editable=!complete || faja && !widthComplete
    fun change(key:String,value:String) {raw=JSONObject(state.set(key,value).values).toString();dirty=true;review=false;files=emptyList()}
    LaunchedEffect(id) {
        if(!loaded) try {
            val saved=repo.load(id,format)
            if(saved!=null) {
                raw=JSONObject(saved.values).toString();source=saved.sourceRecordId
                complete=db.inventoryDao().sicExtension(id)?.status=="COMPLETE"
                val snapshot=db.inventoryDao().snapshot(id)!!
                paths=snapshot.photos.sortedBy {it.photoIndex}.map {it.localPath}
                if(snapshot.record.locationSource!="CONTRACTUAL_PR_ONLY") fix=GeoLocation(snapshot.record.latitude,snapshot.record.longitude,snapshot.record.gpsAccuracyM?.toFloat() ?: Float.POSITIVE_INFINITY,snapshot.record.altitudeM)
                snapshot.record.endLatitude?.let {endFix=GeoLocation(it,snapshot.record.endLongitude!!,snapshot.record.endGpsAccuracyM?.toFloat() ?: Float.POSITIVE_INFINITY)}
                if(faja) {
                    val children=db.inventoryDao().observeSicExtensions().first().filter {it.formatCode=="SIC-09" && it.sourceRecordId==id}
                    (children.firstOrNull {it.status=="DRAFT"} ?: children.firstOrNull())?.let {child->
                        widthId=child.recordId;widthRaw=JSONObject(child.values().filterKeys {it in setOf("usefulWidthM","totalWidthM")}).toString();widthComplete=child.status=="COMPLETE"
                    }
                }
            } else {
                val initial=mutableMapOf("surveyDate" to LocalDate.now().format(SicFieldFormat.dateFormatter))
                session?.road?.let {initial["routeCode"]=it};session?.roadbed?.let {initial["roadbedCode"]=it}
                initial.putAll(SicCaptureContext(context).values(session));raw=JSONObject(initial).toString()
            }
            loaded=true
        } catch(e:Exception) {notice=e.message}
    }
    fun leave() {if(dirty)exit=true else onBack()}
    fun save(finalize:Boolean,after:(()->Unit)?=null) {
        if(busy)return
        busy=true
        scope.launch {try {
            val owner=vm.field.auth.sessions.requireUser().id
            if(finalize) require(completion.canFinalize) {"Revisa los pendientes antes de finalizar"}
            if(faja) repo.saveFaja(id,state,widthId,widths,owner,finalize,paths,captures)
            else repo.save(id,state,owner,finalize,paths,captures=captures,sessionId=session?.sessionId)
            complete=db.inventoryDao().sicExtension(id)?.status=="COMPLETE"
            widthComplete=db.inventoryDao().sicExtension(widthId)?.status=="COMPLETE"
            dirty=false;review=false;notice=if(finalize) "✓ Finalizado · guardado en tablet" else "✓ Borrador guardado en tablet"
            if(finalize) SicCaptureContext(context).remember(session,state)
            after?.invoke()
        } catch(e:Exception) {notice=e.message} finally {busy=false}}
    }
    BackHandler(enabled=!busy) {leave()}
    Box(Modifier.fillMaxSize(),contentAlignment=androidx.compose.ui.Alignment.TopCenter) {
      LazyColumn(Modifier.widthIn(max=1000.dp).fillMaxSize().padding(horizontal=24.dp),contentPadding=PaddingValues(vertical=24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        item {
            OutlinedButton(enabled=!busy,onClick={leave()}) {Text("Volver")}
            Text(InventoryElements.title(format.code),style=MaterialTheme.typography.headlineMedium)
            Text(if(faja) "SIC-08 · SIC-09" else format.code,style=MaterialTheme.typography.bodySmall)
        }
        item {InventoryFormSection("Identificación") {
            InventoryFieldRows(format.fields.filter {it.key in setOf("routeCode","roadbedCode","faja","surveyDate")}) {field->SicFieldInput(field,state.text(field.key),{change(field.key,it)},!complete && !busy)}
        }}
        item {InventoryFormSection(if(format.hasEnd) "Ubicación inicio" else "Ubicación") {
            LocationSummaryCard(fix?.latitude,fix?.longitude,fix?.horizontalAccuracy?.toDouble(),"${state.text("startPrCode")} + ${state.text("startDistanceM")} m",state.text("routeCode"),"PR contractual") {
                if(!complete && !busy) FinalLocationCapture(fix,{fix=it;raw=JSONObject(values(raw)+mapOf("_latitude" to it.latitude.toString(),"_longitude" to it.longitude.toString(),"_accuracy" to it.horizontalAccuracy.toString(),"_altitude" to it.altitude.toString())).toString();dirty=true},"inicio")
            }
            InventoryFieldRows(format.fields.filter {it.key in setOf("startPrCode","startDistanceM")}) {field->SicFieldInput(field,state.text(field.key),{change(field.key,it)},!complete && !busy)}
        }}
        if(format.hasEnd) item {InventoryFormSection("Ubicación fin") {
            LocationSummaryCard(endFix?.latitude,endFix?.longitude,endFix?.horizontalAccuracy?.toDouble(),"${state.text("endPrCode")} + ${state.text("endDistanceM")} m",state.text("routeCode"),"PR contractual") {
                if(!complete && !busy) FinalLocationCapture(endFix,{endFix=it;raw=JSONObject(values(raw)+mapOf("_endLatitude" to it.latitude.toString(),"_endLongitude" to it.longitude.toString(),"_endAccuracy" to it.horizontalAccuracy.toString())).toString();dirty=true},"fin")
            }
            InventoryFieldRows(format.fields.filter {it.key in setOf("endPrCode","endDistanceM")}) {field->SicFieldInput(field,state.text(field.key),{change(field.key,it)},!complete && !busy)}
        }}
        item {InventoryFormSection(if(faja) "Características de la faja" else "Datos del elemento",if(faja) "Formato SIC-08" else format.code) {
            InventoryFieldRows(format.fields.filter {it.key !in SicFieldRepository.sharedKeys && it.key !in setOf("faja","description","levelCode")}) {field->SicFieldInput(field,state.text(field.key),{change(field.key,it)},!complete && !busy)}
            if(format==SicFieldFormat.SIC13) TechnicalCriterion("Ver criterio") {Text(SicFieldFormat.criticalClasses.find {it.code==state.text("classCode")}?.description.orEmpty())}
        }}
        if(faja) item {InventoryFormSection("Ancho de la faja","Formato SIC-09 · opcional al registrar características") {
            Text("Características · ${if(complete) "✓" else "Pendiente"} · Anchos · ${if(widthComplete) "✓" else "Pendiente"}")
            val children=extensions.filter {it.formatCode=="SIC-09" && it.sourceRecordId==id}
            if(children.size>1) ChoiceSelector(children.mapIndexed {i,_->"Medición de anchos ${i+1}"},"Medición de anchos ${children.indexOfFirst {it.recordId==widthId}+1}",!busy && !dirty) {label->
                val child=children[label.substringAfterLast(' ').toInt()-1];widthId=child.recordId;widthRaw=JSONObject(child.values().filterKeys {it in setOf("usefulWidthM","totalWidthM")}).toString();widthComplete=child.status=="COMPLETE"
            }
            if(!widthComplete) OutlinedButton(onClick={widthExpanded=true}) {Text("Completar anchos")}
            if(widthExpanded || widthStarted || widthComplete) InventoryFieldRows(SicFieldFormat.SIC09.fields.filter {it.key in setOf("usefulWidthM","totalWidthM")}) {field->
                SicFieldInput(field,widths[field.key].orEmpty(),{widthRaw=JSONObject(widths+(field.key to it)).toString();dirty=true;review=false},!widthComplete && !busy)
            }
            if(!widthComplete) Text("Puedes guardar la faja y completar anchos aquí después",style=MaterialTheme.typography.bodySmall)
        }}
        if(format==SicFieldFormat.SIC34) item {InventoryFormSection("Nivel") {
            SicCodeDropdown(SicFieldFormat.SIC34.fields.single {it.key=="levelCode"},state.text("levelCode"),{change("levelCode",it)},!complete && !busy)
            TechnicalCriterion("Ver criterio") {Text(SicFieldFormat.levels.find {it.code==state.text("levelCode")}?.description.orEmpty())}
        }}
        item {InventoryElementPhotos(paths,!complete && !busy,{paths=it;dirty=true},{path,metadata->captures=captures+(path to metadata)})}
        if(format.fields.any {it.key=="description"}) item {InventoryFormSection("Observaciones") {SicFieldInput(format.fields.single {it.key=="description"},state.text("description"),{change("description",it)},!complete && !busy)}}
        item {
            if(review || !editable) RecordReviewSection("REVISIÓN",format.fields.map {f->f.label to (f.options.find {it.code==state.text(f.key)}?.name ?: state.text(f.key))}+if(faja) listOf("Ancho útil" to widthState.text("usefulWidthM"),"Ancho total" to widthState.text("totalWidthM")) else emptyList(),paths.map(::File),completion,initiallyExpanded=true)
            notice?.let {Text(it)}
            if(busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if(editable) {
                Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(enabled=loaded && !busy,onClick={save(false)}) {Text("Guardar borrador")}
                    Button(enabled=loaded && !busy,onClick={review=true}) {Text("Revisar y finalizar")}
                }
                if(review) {
                    OutlinedButton(onClick={review=false}) {Text("Volver a editar")}
                    Button(enabled=!busy && completion.canFinalize,onClick={save(true)}) {Text("Finalizar")}
                }
            }
            if(complete) Button(enabled=!busy && !dirty,onClick={busy=true;scope.launch {try {
                files=ElementExports.prepare(context,db,id,vm.localExport.savedHeading)
                notice="Se generaron ${files.size} formatos para esta ${if(faja) "faja" else "ficha"}"
            } catch(e:Exception) {notice=e.message} finally {busy=false}}}) {Text("Exportar")}
            GeneratedElementFiles(files) {notice=it}
        }
      }
    }
    if(exit) AlertDialog(onDismissRequest={exit=false},title={Text("Guardar cambios")},text={Text("Conserva los cambios como borrador antes de volver")},confirmButton={TextButton(enabled=!busy,onClick={save(false){exit=false;onBack()}}) {Text("Guardar borrador y volver")}},dismissButton={TextButton(onClick={exit=false}) {Text("Seguir editando")}})
}

@Composable internal fun SicFieldInput(field:SicField,value:String,onChange:(String)->Unit,enabled:Boolean) {
    if(field.options.isNotEmpty()) SicCodeDropdown(field,value,onChange,enabled)
    else OutlinedTextField(value,onChange,readOnly=!enabled,label={Text(field.label)},singleLine=field.key!="description",minLines=if(field.key=="description")3 else 1,
        keyboardOptions=KeyboardOptions(keyboardType=if(field.kind in setOf(CellKind.DECIMAL,CellKind.INTEGER))KeyboardType.Decimal else KeyboardType.Text),modifier=Modifier.fillMaxWidth())
}

@Composable internal fun TechnicalCriterion(label:String,content:@Composable ()->Unit) {
    var expanded by remember {mutableStateOf(false)}
    TextButton(onClick={expanded=!expanded}) {Text(if(expanded) "Ocultar criterio" else label)}
    if(expanded) content()
}

@Composable fun GeneratedElementFiles(files:List<GeneratedFile>,onError:(String)->Unit) {
    val context=LocalContext.current
    files.forEach {file->
        Text(File(file.localPath).name)
        Row {
            TextButton(onClick={runCatching {context.startActivity(GeneratedFileIndex.open(context,file))}.onFailure {onError("No hay visor compatible")}}) {Text("Abrir")}
            TextButton(onClick={runCatching {context.startActivity(GeneratedFileIndex.share(context,file))}.onFailure {onError("No se pudo compartir")}}) {Text("Compartir")}
        }
    }
}

@Composable fun NewSicDashboard(vm:InventoryViewModel,onOpen:(SicFieldFormat)->Unit) {
    InventoryElementDashboard(onOpen)
}

@Composable fun InventoryElementDashboard(onOpen:(SicFieldFormat)->Unit) {
    Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
        InventoryElements.dashboard.groupBy {it.family}.forEach {(family,entries)->
            Text(family,style=MaterialTheme.typography.titleSmall)
            InventoryFieldRows(entries) {entry->com.tuempresa.inventariovial.InventoryElementButton(entry.title,entry.subtitle) {onOpen(entry.format)}}
        }
    }
}
